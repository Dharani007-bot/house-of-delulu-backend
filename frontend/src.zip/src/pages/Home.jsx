import Header from "../components/Header";
import Hero from "../components/Hero";
import NewsSidebar from "../components/NewsSidebar";
import BestSeller from "../components/BestSeller";
import Promise from "../components/Promise";
import NewArrivals from "../components/NewArrivals";
import QuickLinks from "../components/QuickLinks";
import Footer from "../components/Footer";
import useScrollReveal from "../hooks/useScrollReveal";

function Home() {
  const promiseReveal    = useScrollReveal();
  const bestsellerReveal = useScrollReveal();
  const arrivalsReveal   = useScrollReveal();

  return (
    <>
      {/* ── PHASE 1: masthead + hero + news, fits one screen ── */}
      <div className="hero-frame">
        <Header />
        <div className="hero-news-wrapper">
          <Hero />
          <NewsSidebar />
        </div>
      </div>

       <QuickLinks />

      {/* ── PHASE 2: best sellers ── */}

      <div ref={bestsellerReveal} className="reveal">
        <BestSeller />
      </div>

      {/* ── PHASE 3: new arrivals, newspaper grid ── */}
      <div ref={arrivalsReveal} className="reveal">
        <NewArrivals />
      </div>

      <div ref={promiseReveal} className="reveal">
        <Promise />
      </div>

      <Footer />
    </>
  );
}

export default Home;