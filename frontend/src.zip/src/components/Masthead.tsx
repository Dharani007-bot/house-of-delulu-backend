const CROWN = (
  <svg viewBox="0 0 24 24" width="30" height="30" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path
      d="M3 8L7 12L12 5L17 12L21 8L19 18H5L3 8Z"
      stroke="#b08d3f"
      strokeWidth="1.2"
      strokeLinejoin="round"
      fill="#b08d3f"
    />
  </svg>
);

/** Newspaper masthead: crown, brand, edition info, department toggle, rules. */
export default function Masthead({
  brand = "HOUSE OF DELULU",
  edition = "EDITION: 01",
  established = "EST. 2026",
  dept = "women",
}: {
  brand?: string;
  edition?: string;
  established?: string;
  dept?: "men" | "women";
}) {
  return (
    <header>
      <div className="crown-wrap">{CROWN}</div>

      <div className="top-bar">
        <div>
          <p>{established}</p>
          <p>{edition}</p>
        </div>

        <h1>{brand}</h1>

        <div className="dept-toggle">
          <a href="/" className={dept === "men" ? "dept-link active" : "dept-link"}>
            MEN&apos;S WEAR
          </a>
          <a href="/" className={dept === "women" ? "dept-link active" : "dept-link"}>
            WOMEN&apos;S WEAR
          </a>
        </div>
      </div>

      <p className="tagline">CONFIDENCE. STYLE. DELULU.</p>

      <hr className="header-divider" />

      <div className="sub-bar">
        <span>
          DESIGNED TO BE <span className="gold">REMEMBERED.</span>
        </span>
        <span>WWW.HOUSEOFDELULU.COM</span>
        <span>
          MADE TO <span className="gold">EMPOWER.</span>
        </span>
      </div>
    </header>
  );
}
