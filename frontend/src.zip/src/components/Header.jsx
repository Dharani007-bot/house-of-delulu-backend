import { useState } from "react";
import Navbar from "./Navbar";
import DeptMegaMenu from "./DeptMegaMenu";
import useDept from "../hooks/useDept";

function Header() {
  const dept = useDept();
  const [hovered, setHovered] = useState(null); // "men" | "women" | null

  return (
    <>
      <Navbar />
      <header>
        <div className="crown-wrap">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 8L7 12L12 5L17 12L21 8L19 18H5L3 8Z" stroke="#d4af37" strokeWidth="1.5" strokeLinejoin="round" fill="#d4af37"/>
          </svg>
        </div>

        <div className="top-bar">
          <div>
            <p>EST. 2026</p>
            <p>EDITION: 01</p>
          </div>
          <h1>HOUSE OF DELULU</h1>

          <div className="dept-toggle">
            <div
              className="dept-item"
              onMouseEnter={() => setHovered("men")}
              onMouseLeave={() => setHovered(null)}
            >
              <a href="/men" className={dept === "men" ? "dept-link active" : "dept-link"}>
                MEN'S WEAR
              </a>
              <DeptMegaMenu dept="men" active={hovered === "men"} />
            </div>

            <div
              className="dept-item"
              onMouseEnter={() => setHovered("women")}
              onMouseLeave={() => setHovered(null)}
            >
              <a href="/women" className={dept === "women" ? "dept-link active" : "dept-link"}>
                WOMEN'S WEAR
              </a>
              <DeptMegaMenu dept="women" active={hovered === "women"} />
            </div>
          </div>
        </div>

        <p className="tagline">CONFIDENCE • STYLE • DELULU</p>

        <hr className="header-divider" />

        <div className="sub-bar">
          <span>DESIGNED TO BE <span className="gold">REMEMBERED.</span></span>
          <span>WWW.HOUSE OF DELULU.COM</span>
          <span>MADE TO <span className="gold">EMPOWER.</span></span>
        </div>
      </header>
    </>
  );
}

export default Header;