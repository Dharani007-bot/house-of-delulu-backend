import { Link } from "react-router-dom";
import news1 from "../assets/news1.jpg";
import news2 from "../assets/news2.jpg";
import news3 from "../assets/news3.jpg";
import useDept from "../hooks/useDept";
import useScrollReveal from "../hooks/useScrollReveal";

function NewsSidebar() {
  const dept = useDept();
  const reveal = useScrollReveal();

  const items = [
    {
      img: news1,
      title: "NEW COLLECTION",
      text: "Timeless pieces. Modern attitude.",
      cta: "EXPLORE NOW ›",
      to: `/${dept}/shop`,
    },
    {
      img: news2,
      title: "PREMIUM QUALITY",
      text: "Carefully crafted. Made to last.",
      cta: "LEARN MORE ›",
      to: `/${dept}/shop`,
    },
    {
      img: news3,
      title: "EXCLUSIVE ACCESS",
      text: "Be the first to know about new drops and special offers.",
      cta: "SIGN UP NOW ›",
      to: `/${dept}/shop`,
    },
  ];

  return (
    <section
      ref={reveal}
      className="news-section reveal reveal-right"
    >
      <h2>DAILY FASHION NEWS</h2>

      {items.map((item) => (
        <article className="news-card" key={item.title}>
          <img
            src={item.img}
            alt={item.title}
            loading="lazy"
            width={640}
            height={512}
          />

          <div className="news-content">
            <h3>{item.title}</h3>

            <p>{item.text}</p>

            <Link to={item.to}>
              {item.cta}
            </Link>
          </div>
        </article>
      ))}
    </section>
  );
}

export default NewsSidebar;