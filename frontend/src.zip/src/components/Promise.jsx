import promise from "../assets/promise.jpg";
import useDept from "../hooks/useDept";
import useScrollReveal from "../hooks/useScrollReveal";
import { Link } from "react-router-dom";

function Promise() {
    const dept = useDept();
    return (
        <section className="promise">
            <div className="promise-left">
                <h2>OUR PROMISE</h2>
                <img src={promise} alt="Promise" />
            </div>
            <div className="promise-right">
                <div className="promise-item">
                    <Link to={`/${dept}/shop`}>
                    <h3>PREMIUM QUALITY</h3>
                    </Link>
                    <p>
                        Finest fabrics with premium craftsmanship.
                    </p>
                </div>

                <div className="promise-item">
                    <Link to={`/${dept}/shop`}>
                    <h3>MADE FOR YOU</h3>
                    </Link>
                    <p>
                        Designed to fit your lifestyle.
                    </p>
                </div>
                <div className="promise-item">
                    <Link to={`/${dept}/shop`}>
                    <h3>EXCLUSIVE DESIGNS</h3>
                    </Link>
                    <p>
                        Unique collections available only at ATIX.
                    </p>
                </div>
            </div>
        </section>

    );

}

export default Promise;