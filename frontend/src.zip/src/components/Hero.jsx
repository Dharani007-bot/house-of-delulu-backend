import { Link } from "react-router-dom";
import heroImg from "../assets/hero.jpg";
import useDept from "../hooks/useDept";

function Hero({
  headline = ["FASHION THAT", "SPEAKS ", "YOU."],
  body = "At House of Delulu, we don't follow trends, we create statements. Every piece is designed for the bold, the confident, and the beautifully delulu in you.",
  cta = "SHOP THE COLLECTION ▶",
  image = heroImg,
  imageAlt = "Woman in a black crested blazer on a city street",
}) {
  const dept = useDept();

  return (
    <section className="hero">
      <div className="hero-left">
        <h2>
          {headline[0]}
          <br />
          {headline[1]}
          <span>{headline[2]}</span>
        </h2>

        <p>{body}</p>

        <Link to={`/${dept}/shop`}>
          <button type="button">
            <span>{cta}</span>
          </button>
        </Link>
      </div>

      <div className="hero-right">
        <img
          src={image}
          alt={imageAlt}
          width={1024}
          height={1280}
        />
      </div>
    </section>
  );
}

export default Hero;